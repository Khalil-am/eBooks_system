﻿using eTickets.Data.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace eTickets.Models
{
    public class Library:IEntityBase
    {
        [Key]
        public int Id { get; set; }

        [Display(Name = "Library Logo")]
        [Required(ErrorMessage = "Library logo is required")]
        public string Logo { get; set; }

        [Display(Name = "Library Name")]
        [Required(ErrorMessage = "Library name is required")]
        public string Name { get; set; }

        [Display(Name = "Description")]
        [Required(ErrorMessage = "Library description is required")]
        public string Description { get; set; }

        //Relationships
        public List<Book> Movies { get; set; }
    }
}
