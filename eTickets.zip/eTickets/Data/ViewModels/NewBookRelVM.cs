﻿using eTickets.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eTickets.Data.ViewModels
{
    public class NewBookRelVm
    {
        public NewBookRelVm()
        {
            Publishers = new List<Publisher>();
            Librarys = new List<Library>();
            Authors = new List<Author>();
        }

        public List<Publisher> Publishers { get; set; }
        public List<Library> Librarys { get; set; }
        public List<Author> Authors { get; set; }
    }
}
