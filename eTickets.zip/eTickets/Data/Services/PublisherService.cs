﻿using eTickets.Data.Base;
using eTickets.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eTickets.Data.Services
{
    public class PublisherService: EntityBaseRepository<Publisher>, IPublisherService
    {
        public PublisherService(AppDbContext context) : base(context)
        {
        }
    }
}
