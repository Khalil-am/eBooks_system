﻿using eTickets.Data.Base;
using eTickets.Data.ViewModels;
using eTickets.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eTickets.Data.Services
{
    public class BooksService : EntityBaseRepository<Book>, IBooksService
    {
        private readonly AppDbContext _context;
        public BooksService(AppDbContext context) : base(context)
        {
            _context = context;
        }

        public async Task AddNewBookAsync(NewBookVM data)
        {
            var newMovie = new Book()
            {
                Name = data.Name,
                Description = data.Description,
                Price = data.Price,
                ImageURL = data.ImageURL,
                LibraryId = data.LibraryId,
                RelDate = data.StartDate,
                EndDate = data.EndDate,
                BookCategory = data.BookCategory,
                PublisherId = data.PublisherId
            };
            await _context.Books.AddAsync(newMovie);
            await _context.SaveChangesAsync();

            //Add Movie Actors
            foreach (var actorId in data.AuthorId)
            {
                var newActorMovie = new Author_Books()
                {
                    BookId = newMovie.Id,
                    AuthorId = actorId
                };
                await _context.Author_Books.AddAsync(newActorMovie);
            }
            await _context.SaveChangesAsync();
        }

        public async Task<Book> GetBookByIdAsync(int id)
        {
            var movieDetails = await _context.Books
                .Include(c => c.Library)
                .Include(p => p.Publisher)
                .Include(am => am.Author_Books).ThenInclude(a => a.Author)
                .FirstOrDefaultAsync(n => n.Id == id);

            return movieDetails;
        }

        public async Task<NewBookRelVm> GetNewBookDropdownsValues()
        {
            var response = new NewBookRelVm()
            {
                Authors = await _context.Authors.OrderBy(n => n.FullName).ToListAsync(),
                Librarys = await _context.Librarys.OrderBy(n => n.Name).ToListAsync(),
                Publishers = await _context.Publishers.OrderBy(n => n.FullName).ToListAsync()
            };

            return response;
        }

        public async Task UpdateBookAsync(NewBookVM data)
        {
            var dbMovie = await _context.Books.FirstOrDefaultAsync(n => n.Id == data.Id);

            if(dbMovie != null)
            {
                dbMovie.Name = data.Name;
                dbMovie.Description = data.Description;
                dbMovie.Price = data.Price;
                dbMovie.ImageURL = data.ImageURL;
                dbMovie.LibraryId = data.LibraryId;
                dbMovie.RelDate = data.StartDate;
                dbMovie.EndDate = data.EndDate;
                dbMovie.BookCategory = data.BookCategory;
                dbMovie.PublisherId = data.PublisherId;
                await _context.SaveChangesAsync();
            }

            //Remove existing actors
            var existingActorsDb = _context.Author_Books.Where(n => n.BookId == data.Id).ToList();
            _context.Author_Books.RemoveRange(existingActorsDb);
            await _context.SaveChangesAsync();

            //Add Movie Actors
            foreach (var actorId in data.AuthorId)
            {
                var newActorMovie = new Author_Books()
                {
                    BookId = data.Id,
                    AuthorId = actorId
                };
                await _context.Author_Books.AddAsync(newActorMovie);
            }
            await _context.SaveChangesAsync();
        }
    }
}
