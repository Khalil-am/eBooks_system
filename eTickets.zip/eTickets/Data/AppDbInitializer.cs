﻿using eTickets.Data.Static;
using eTickets.Models;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eTickets.Data
{
    public class AppDbInitializer
    {
        public static void Seed(IApplicationBuilder applicationBuilder)
        {
            using (var serviceScope = applicationBuilder.ApplicationServices.CreateScope())
            {
                var context = serviceScope.ServiceProvider.GetService<AppDbContext>();

                context.Database.EnsureCreated();

                //Library
                if (!context.Librarys.Any())
                {
                    context.Librarys.AddRange(new List<Library>()
                    {
                        new Library()
                        {
                            Name = "Library 1",
                            Logo = "http://dotnethow.net/images/cinemas/cinema-1.jpeg",
                            Description = "This is the description of the first Library"
                        },
                        new Library()
                        {
                            Name = "Library 2",
                            Logo = "http://dotnethow.net/images/cinemas/cinema-2.jpeg",
                            Description = "This is the description of the first Library"
                        },
                        new Library()
                        {
                            Name = "Library 3",
                            Logo = "http://dotnethow.net/images/cinemas/cinema-3.jpeg",
                            Description = "This is the description of the first Library"
                        },
                        new Library()
                        {
                            Name = "Library 4",
                            Logo = "http://dotnethow.net/images/cinemas/cinema-4.jpeg",
                            Description = "This is the description of the first Library"
                        },
                        new Library()
                        {
                            Name = "Library 5",
                            Logo = "http://dotnethow.net/images/cinemas/cinema-5.jpeg",
                            Description = "This is the description of the first Library"
                        },
                    });
                    context.SaveChanges();
                }
                //Authors
                if (!context.Authors.Any())
                {
                    context.Authors.AddRange(new List<Author>()
                    {
                        new Author()
                        {
                            FullName = "Author 1",
                            Bio = "This is the Bio of the first Author",
                            ProfilePictureURL = "http://dotnethow.net/images/actors/actor-1.jpeg"

                        },
                        new Author()
                        {
                            FullName = "Author 2",
                            Bio = "This is the Bio of the second Author",
                            ProfilePictureURL = "http://dotnethow.net/images/actors/actor-2.jpeg"
                        },
                        new Author()
                        {
                            FullName = "Author 3",
                            Bio = "This is the Bio of the second Author",
                            ProfilePictureURL = "http://dotnethow.net/images/actors/actor-3.jpeg"
                        },
                        new Author()
                        {
                            FullName = "Author 4",
                            Bio = "This is the Bio of the second Author",
                            ProfilePictureURL = "http://dotnethow.net/images/actors/actor-4.jpeg"
                        },
                        new Author()
                        {
                            FullName = "Author 5",
                            Bio = "This is the Bio of the second Author",
                            ProfilePictureURL = "http://dotnethow.net/images/actors/actor-5.jpeg"
                        }
                    });
                    context.SaveChanges();
                }
                //Publishers
                if (!context.Publishers.Any())
                {
                    context.Publishers.AddRange(new List<Publisher>()
                    {
                        new Publisher()
                        {
                            FullName = "Publisher 1",
                            Bio = "This is the Bio of the first Publisher",
                            ProfilePictureURL = "http://dotnethow.net/images/producers/producer-1.jpeg"

                        },
                        new Publisher()
                        {
                            FullName = "Publisher 2",
                            Bio = "This is the Bio of the second Publisher",
                            ProfilePictureURL = "http://dotnethow.net/images/producers/producer-2.jpeg"
                        },
                        new Publisher()
                        {
                            FullName = "Publisher 3",
                            Bio = "This is the Bio of the second Publisher",
                            ProfilePictureURL = "http://dotnethow.net/images/producers/producer-3.jpeg"
                        },
                        new Publisher()
                        {
                            FullName = "Publisher 4",
                            Bio = "This is the Bio of the second Publisher",
                            ProfilePictureURL = "http://dotnethow.net/images/producers/producer-4.jpeg"
                        },
                        new Publisher()
                        {
                            FullName = "Producer 5",
                            Bio = "This is the Bio of the second Publisher",
                            ProfilePictureURL = "http://dotnethow.net/images/producers/producer-5.jpeg"
                        }
                    });
                    context.SaveChanges();
                }
                //Books
                if (!context.Books.Any())
                {
                    context.Books.AddRange(new List<Book>()
                    {
                        new Book()
                        {
                            Name = "Life",
                            Description = "This is the Life movie description",
                            Price = 39.50,
                            ImageURL = "http://dotnethow.net/images/movies/movie-3.jpeg",
                            RelDate = DateTime.Now.AddDays(-10),
                            EndDate = DateTime.Now.AddDays(10),
                            LibraryId = 3,
                            PublisherId = 3,
                            BookCategory = BookCategory.Documentary
                        },
                        new Book()
                        {
                            Name = "The Shawshank Redemption",
                            Description = "This is the Shawshank Redemption description",
                            Price = 29.50,
                            ImageURL = "http://dotnethow.net/images/movies/movie-1.jpeg",
                            RelDate = DateTime.Now,
                            EndDate = DateTime.Now.AddDays(3),
                            LibraryId = 1,
                            PublisherId = 1,
                            BookCategory = BookCategory.Action
                        },
                        new Book()
                        {
                            Name = "Ghost",
                            Description = "This is the Ghost movie description",
                            Price = 39.50,
                            ImageURL = "http://dotnethow.net/images/movies/movie-4.jpeg",
                            RelDate = DateTime.Now,
                            EndDate = DateTime.Now.AddDays(7),
                            LibraryId = 4,
                            PublisherId = 4,
                            BookCategory = BookCategory.Horror
                        },
                        new Book()
                        {
                            Name = "Race",
                            Description = "This is the Race movie description",
                            Price = 39.50,
                            ImageURL = "http://dotnethow.net/images/movies/movie-6.jpeg",
                            RelDate = DateTime.Now.AddDays(-10),
                            EndDate = DateTime.Now.AddDays(-5),
                            LibraryId = 1,
                            PublisherId = 2,
                            BookCategory = BookCategory.Documentary
                        },
                        new Book()
                        {
                            Name = "Scoob",
                            Description = "This is the Scoob movie description",
                            Price = 39.50,
                            ImageURL = "http://dotnethow.net/images/movies/movie-7.jpeg",
                            RelDate = DateTime.Now.AddDays(-10),
                            EndDate = DateTime.Now.AddDays(-2),
                            LibraryId = 1,
                            PublisherId = 3,
                            BookCategory = BookCategory.Cartoon
                        },
                        new Book()
                        {
                            Name = "Cold Soles",
                            Description = "This is the Cold Soles movie description",
                            Price = 39.50,
                            ImageURL = "http://dotnethow.net/images/movies/movie-8.jpeg",
                            RelDate = DateTime.Now.AddDays(3),
                            EndDate = DateTime.Now.AddDays(20),
                            LibraryId = 1,
                            PublisherId = 5,
                            BookCategory = BookCategory.Drama
                        }
                    });
                    context.SaveChanges();
                }
                //Author & Books
                if (!context.Author_Books.Any())
                {
                    context.Author_Books.AddRange(new List<Author_Books>()
                    {
                        new Author_Books()
                        {
                            AuthorId = 1,
                            BookId = 1
                        },
                        new Author_Books()
                        {
                            AuthorId = 3,
                            BookId = 1
                        },

                         new Author_Books()
                        {
                            AuthorId = 1,
                            BookId = 2
                        },
                         new Author_Books()
                        {
                            AuthorId = 4,
                            BookId = 2
                        },

                        new Author_Books()
                        {
                            AuthorId = 1,
                            BookId = 3
                        },
                        new Author_Books()
                        {
                            AuthorId = 2,
                            BookId = 3
                        },
                        new Author_Books()
                        {
                            AuthorId = 5,
                            BookId = 3
                        },


                        new Author_Books()
                        {
                            AuthorId = 2,
                            BookId = 4
                        },
                        new Author_Books()
                        {
                            AuthorId = 3,
                            BookId = 4
                        },
                        new Author_Books()
                        {
                            AuthorId = 4,
                            BookId = 4
                        },


                        new Author_Books()
                        {
                            AuthorId = 2,
                            BookId = 5
                        },
                        new Author_Books()
                        {
                            AuthorId = 3,
                            BookId = 5
                        },
                        new Author_Books()
                        {
                            AuthorId = 4,
                            BookId = 5
                        },
                        new Author_Books()
                        {
                            AuthorId = 5,
                            BookId = 5
                        },


                        new Author_Books()
                        {
                            AuthorId = 3,
                            BookId = 6
                        },
                        new Author_Books()
                        {
                            AuthorId = 4,
                            BookId = 6
                        },
                        new Author_Books()
                        {
                            AuthorId = 5,
                            BookId = 6
                        },
                    });
                    context.SaveChanges();
                }
            }

        }

        public static async Task SeedUsersAndRolesAsync(IApplicationBuilder applicationBuilder)
        {
            using (var serviceScope = applicationBuilder.ApplicationServices.CreateScope())
            {

                //Roles
                var roleManager = serviceScope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();

                if (!await roleManager.RoleExistsAsync(UserRoles.Admin))
                    await roleManager.CreateAsync(new IdentityRole(UserRoles.Admin));
                if (!await roleManager.RoleExistsAsync(UserRoles.User))
                    await roleManager.CreateAsync(new IdentityRole(UserRoles.User));

                //Users
                var userManager = serviceScope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();
                string adminUserEmail = "admin@eBooks.com";

                var adminUser = await userManager.FindByEmailAsync(adminUserEmail);
                if(adminUser == null)
                {
                    var newAdminUser = new ApplicationUser()
                    {
                        FullName = "Admin User",
                        UserName = "admin-user",
                        Email = adminUserEmail,
                        EmailConfirmed = true
                    };
                    await userManager.CreateAsync(newAdminUser, "19981998");
                    await userManager.AddToRoleAsync(newAdminUser, UserRoles.Admin);
                }


                string appUserEmail = "user@eBooks.com";

                var appUser = await userManager.FindByEmailAsync(appUserEmail);
                if (appUser == null)
                {
                    var newAppUser = new ApplicationUser()
                    {
                        FullName = "Application User",
                        UserName = "app-user",
                        Email = appUserEmail,
                        EmailConfirmed = true
                    };
                    await userManager.CreateAsync(newAppUser, "19981998");
                    await userManager.AddToRoleAsync(newAppUser, UserRoles.User);
                }
            }
        }
    }
}
